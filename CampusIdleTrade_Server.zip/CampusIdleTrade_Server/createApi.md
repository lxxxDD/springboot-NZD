# Spring Boot + MyBatis-Plus 快速开发指南

## 一、开发环境准备

### 1. 开发工具
- JDK 8 及以上版本
- 开发 IDE：IntelliJ IDEA（推荐）或 Eclipse
- 数据库：MySQL 8.0
- 构建工具：Maven 3.6+

### 2. 项目依赖配置（pom.xml）

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.7.0</version> <!-- 稳定版本，可根据需求调整 -->
    <relativePath/>
</parent>

<dependencies>
    <!-- 1. Spring Web 核心依赖（提供 HTTP 接口能力） -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- 2. MySQL 数据库驱动（连接 MySQL） -->
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
        <scope>runtime</scope>
    </dependency>

    <!-- 3. Lombok（简化实体类代码，自动生成 getter/setter 等） -->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>

    <!-- 4. MyBatis-Plus 核心依赖（简化 CRUD 操作） -->
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-boot-starter</artifactId>
        <version>3.5.3.1</version> <!-- 最新稳定版，可查官网更新 -->
    </dependency>

    <!-- 5. 测试依赖（可选，用于单元测试） -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

## 二、核心配置文件（application.yml）

```yaml
# 服务端口配置（默认 8080，可自定义）
server:
  port: 8080

# 数据库连接配置
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    # 数据库 URL：替换为你的数据库名（示例中为 graduation）、用户名、密码
    url: jdbc:mysql://localhost:3306/graduation?useSSL=false&serverTimezone=UTC&characterEncoding=utf8
    username: root       # 你的 MySQL 用户名（默认常为 root）
    password: 123456     # 你的 MySQL 密码（安装时设置的密码）

# MyBatis-Plus 配置
mybatis-plus:
  mapper-locations: classpath:mapper/*.xml  # Mapper.xml 文件存放路径（复杂查询用）
  type-aliases-package: com.example.demo.entity  # 实体类包路径（简化 XML 中类名引用）
  configuration:
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl  # 控制台打印 SQL（调试用，上线可关闭）
```

## 三、数据库表设计（以 user 表为例）

先创建数据库和表，执行以下 SQL 语句（可在 Navicat、MySQL Workbench 等工具中运行）：

```sql
-- 1. 创建数据库（若不存在）
CREATE DATABASE IF NOT EXISTS graduation;
USE graduation;

-- 2. 创建用户表（核心字段：id、姓名、年龄、邮箱）
CREATE TABLE user (
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID（自增）',
    name VARCHAR(30) NOT NULL COMMENT '用户姓名',
    age INT(11) COMMENT '用户年龄',
    email VARCHAR(50) COMMENT '用户邮箱（唯一）',
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表';
```

## 四、代码实现（按分层架构编写）

### 项目包结构

```
com.example.demo  # 根包（替换为你的实际包名）
├── DemoApplication.java       # 项目启动类
├── entity                     # 实体类层（对应数据库表）
│   └── User.java
├── mapper                     # Mapper 接口层（数据访问层）
│   └── UserMapper.java
├── service                    # 服务层（封装业务逻辑）
│   ├── UserService.java       # 服务接口
│   └── impl
│       └── UserServiceImpl.java  # 服务实现类
└── controller                 # 控制器层（暴露 HTTP 接口）
    └── UserController.java
```

### 1. 实体类（entity/User.java）

通过 MyBatis-Plus 注解映射数据库表，Lombok 简化代码：

```java
package com.example.demo.entity;

import lombok.Data;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@Data  // Lombok 注解：自动生成 getter、setter、toString 等方法
@TableName("user")  // 映射数据库表名（需与表名一致）
public class User {
    @TableId(type = IdType.AUTO)  // 主键策略：自增（与数据库表主键自增对应）
    private Long id;               // 主键ID
    private String name;           // 姓名（对应表中 name 字段）
    private Integer age;           // 年龄（对应表中 age 字段）
    private String email;          // 邮箱（对应表中 email 字段）
}
```

### 2. Mapper 接口（mapper/UserMapper.java）

继承 MyBatis-Plus 的 BaseMapper，自动获得基础 CRUD 方法：

```java
package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper  // 标识为 MyBatis 的 Mapper 接口（Spring 会自动扫描）
public interface UserMapper extends BaseMapper<User> {
    // 无需手动写方法！BaseMapper 已包含：
    // insert()（新增）、selectById()（按ID查询）、updateById()（按ID更新）、deleteById()（按ID删除）、list()（查询所有）等
}
```

### 3. 服务层

#### 3.1 服务接口（service/UserService.java）

继承 MyBatis-Plus 的 IService，扩展业务方法（可选）：

```java
package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.entity.User;

public interface UserService extends IService<User> {
    // 基础 CRUD 方法已在 IService 中定义，若需自定义业务方法可在此添加
    // 示例：List<User> getUsersByAge(Integer age);
}
```

#### 3.2 服务实现类（service/impl/UserServiceImpl.java）

继承 ServiceImpl，实现服务接口：

```java
package com.example.demo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.UserService;
import org.springframework.stereotype.Service;

@Service  // 标识为 Spring 服务类（业务逻辑层）
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    // 基础 CRUD 方法已在 ServiceImpl 中实现，无需手动重写
    // 若有自定义业务方法，在此实现（示例：）
    // @Override
    // public List<User> getUsersByAge(Integer age) {
    //     QueryWrapper<User> wrapper = new QueryWrapper<>();
    //     wrapper.eq("age", age);
    //     return baseMapper.selectList(wrapper);
    // }
}
```

### 4. 控制器层（controller/UserController.java）

暴露 HTTP 接口，接收前端请求并调用服务层：

```java
package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController  // 标识为 REST 接口控制器（返回 JSON 数据）
@RequestMapping("/api/users")  // 接口基础路径（所有用户相关接口都以 /api/users 开头）
public class UserController {

    // 注入服务层对象
    @Autowired
    private UserService userService;

    // 1. 新增用户（POST 请求）
    @PostMapping
    public String addUser(@RequestBody User user) {
        // 调用服务层 save() 方法新增用户
        boolean isSuccess = userService.save(user);
        return isSuccess ? "新增用户成功" : "新增用户失败";
    }

    // 2. 按 ID 查询用户（GET 请求）
    @GetMapping("/{id}")  // 路径参数：id（用户ID）
    public User getUserById(@PathVariable Long id) {
        // 调用服务层 getById() 方法查询
        return userService.getById(id);
    }

    // 3. 查询所有用户（GET 请求）
    @GetMapping
    public List<User> getAllUsers() {
        // 调用服务层 list() 方法查询所有
        return userService.list();
    }

    // 4. 按 ID 更新用户（PUT 请求）
    @PutMapping
    public String updateUser(@RequestBody User user) {
        // 调用服务层 updateById() 方法更新（需传入带 ID 的 User 对象）
        boolean isSuccess = userService.updateById(user);
        return isSuccess ? "更新用户成功" : "更新用户失败";
    }

    // 5. 按 ID 删除用户（DELETE 请求）
    @DeleteMapping("/{id}")  // 路径参数：id（用户ID）
    public String deleteUser(@PathVariable Long id) {
        // 调用服务层 removeById() 方法删除
        boolean isSuccess = userService.removeById(id);
        return isSuccess ? "删除用户成功" : "删除用户失败";
    }
}
```

### 5. 项目启动类（DemoApplication.java）

```java
package com.example.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication  // 标识为 Spring Boot 应用
@MapperScan("com.example.demo.mapper")  // 扫描 Mapper 接口所在包（确保 Spring 能找到 Mapper）
public class DemoApplication {
    public static void main(String[] args) {
        // 启动 Spring Boot 应用
        SpringApplication.run(DemoApplication.class, args);
    }
}
```

## 五、自定义 SQL（应对复杂查询，可选）

若需实现多表联查、聚合查询等复杂逻辑，可通过 Mapper.xml 编写自定义 SQL。

### 示例：按年龄查询用户

#### 1. 在 UserMapper.java 中添加方法

```java
package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 自定义方法：按年龄查询用户
    List<User> selectUsersByAge(@Param("age") Integer age);
}
```

#### 2. 创建 Mapper.xml 文件（resources/mapper/UserMapper.xml）

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" 
"http://mybatis.org/dtd/mybatis-3-mapper.dtd">

<!-- namespace 必须与 Mapper 接口的全类名一致 -->
<mapper namespace="com.example.demo.mapper.UserMapper">

    <!-- 自定义查询：按年龄查询用户 -->
    <!-- id：与 Mapper 接口中的方法名一致；resultType：返回结果类型（实体类全路径） -->
    <select id="selectUsersByAge" resultType="com.example.demo.entity.User">
        SELECT * FROM user WHERE age = #{age}  <!-- #{age} 对应 @Param("age") 的参数 -->
    </select>

</mapper>
```

#### 3. 在服务层和控制器层扩展（可选）

- 服务层接口添加方法：`List<User> getUsersByAge(Integer age);`
- 服务实现类实现方法：`return baseMapper.selectUsersByAge(age);`
- 控制器层添加接口：

```java
@GetMapping("/age")
public List<User> getUsersByAge(@RequestParam Integer age) {
    return userService.getUsersByAge(age);
}
```

## 六、接口测试（使用 Postman 或浏览器）

| 接口功能 | 请求方式 | 请求 URL | 请求参数 / 请求体（JSON） | 成功响应示例 |
|---------|---------|----------|-------------------------|-------------|
| 新增用户 | POST | http://localhost:8080/api/users | `{"name":"张三","age":20,"email":"zs@qq.com"}` | 新增用户成功 |
| 按 ID 查询用户 | GET | http://localhost:8080/api/users/1 | 路径参数 id=1 | `{"id":1,"name":"张三","age":20,"email":"zs@qq.com"}` |
| 查询所有用户 | GET | http://localhost:8080/api/users | 无参数 | `[{"id":1,"name":"张三",...}, {...}]` |
| 按 ID 更新用户 | PUT | http://localhost:8080/api/users | `{"id":1,"name":"张三2","age":21}` | 更新用户成功 |
| 按 ID 删除用户 | DELETE | http://localhost:8080/api/users/1 | 路径参数 id=1 | 删除用户成功 |

## 七、核心优势总结

- **开发效率高**：MyBatis-Plus 自动实现基础 CRUD，无需手动写 SQL
- **灵活性强**：支持自定义 SQL 应对复杂场景，兼顾框架便捷性和原生 SQL 控制力
- **学习成本低**：基于 SQL 语法，熟悉 MySQL 即可快速上手
- **适配毕设需求**：快速搭建核心接口，节省时间专注业务逻辑和前端联调