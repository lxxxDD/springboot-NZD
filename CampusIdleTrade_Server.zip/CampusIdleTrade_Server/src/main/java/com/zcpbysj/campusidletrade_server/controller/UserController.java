package com.zcpbysj.campusidletrade_server.controller;

import com.zcpbysj.campusidletrade_server.common.Result;
import com.zcpbysj.campusidletrade_server.entity.User;
import com.zcpbysj.campusidletrade_server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
    //服务员
    //    Controller -> Service -> Mapper -> 数据库 -> Mapper -> Service -> Controller -> 前端。

@RestController  // 标识为 REST 接口控制器（返回 JSON 数据）
@RequestMapping("/user") // 接口基础路径（所有用户相关接口都以 /api/users 开头）
public class UserController {
    // 接口地址：http://localhost:8080/user/list（查询所有用户）
    //    insert()（新增）、selectById()（按ID查询）、updateById()（按ID更新）、deleteById()（按ID删除）、list()（查询所有）等
    // 注入服务层对象
    @Autowired
    private UserService userService;


        // 查询所有用户
        @GetMapping(value = "/list", produces = "application/json")
        public Result<List<User>> getAllUsers() {
            List<User> userList = userService.list();
            return Result.success(userList, "查询用户列表成功");
        }

        // 根据 ID 查询单个用户
        @GetMapping("/{id}")
        public Result<User> getUserById(@PathVariable Long id) {
            User user = userService.getById(id);
            if (user == null) {
                return Result.fail(404, "用户不存在");
            }
            return Result.success(user, "查询用户成功");
        }

        // 根据年龄查询用户
        //自定义sql语句示例
        @GetMapping("/age/{age}")
        public Result<List<User>> getUsersByAge(@PathVariable Integer age) {
            List<User> userList = userService.selectUserByAge(age);
            if (userList.isEmpty()) {
                return Result.fail(404, "未找到该年龄的用户");
            }
            return Result.success(userList, "查询年龄为" + age + "的用户成功");
        }









}
