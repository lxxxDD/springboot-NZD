package com.zcpbysj.campusidletrade_server;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@SpringBootApplication  // 标识为 Spring Boot 应用
@MapperScan("com.zcpbysj.campusidletrade_server.mapper")  // 扫描 Mapper 接口所在包（确保 Spring 能找到 Mapper）
public class CampusIdleTradeServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CampusIdleTradeServerApplication.class, args);
    }

}