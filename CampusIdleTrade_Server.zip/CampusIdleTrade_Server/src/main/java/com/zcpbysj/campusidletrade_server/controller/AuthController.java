package com.zcpbysj.campusidletrade_server.controller;

import com.zcpbysj.campusidletrade_server.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 认证控制器
 * 提供用户登录、注册、令牌刷新等认证相关的API接口
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*") // 允许跨域访问
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * 用户登录接口
     * 验证用户凭据并返回JWT令牌
     * 
     * @param loginRequest 登录请求（包含用户名和密码）
     * @return 登录结果（包含访问令牌和刷新令牌）
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest loginRequest) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // 验证用户名和密码（这里是示例，实际项目中应该查询数据库）
            if (validateUser(loginRequest.getUsername(), loginRequest.getPassword())) {
                // 模拟用户信息（实际项目中从数据库获取）
                Long userId = 1001L;
                String role = "USER";
                
                // 生成令牌对
                Map<String, String> tokens = jwtUtil.generateTokenPair(
                    loginRequest.getUsername(), userId, role);
                
                response.put("success", true);
                response.put("message", "登录成功");
                response.put("accessToken", tokens.get("accessToken"));
                response.put("refreshToken", tokens.get("refreshToken"));
                response.put("user", Map.of(
                    "id", userId,
                    "username", loginRequest.getUsername(),
                    "role", role
                ));
                
                return ResponseEntity.ok()
                    .header("Authorization", "Bearer " + tokens.get("accessToken"))
                    .header("X-Refresh-Token", tokens.get("refreshToken"))
                    .body(response);
            } else {
                response.put("success", false);
                response.put("message", "用户名或密码错误");
                return ResponseEntity.status(401).body(response);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "登录失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    /**
     * 刷新令牌接口
     * 使用刷新令牌获取新的访问令牌
     * 
     * @param refreshRequest 刷新请求（包含刷新令牌）
     * @return 新的访问令牌
     */
    @PostMapping("/refresh")
    public ResponseEntity<Map<String, Object>> refreshToken(@RequestBody RefreshTokenRequest refreshRequest) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String newAccessToken = jwtUtil.refreshAccessToken(refreshRequest.getRefreshToken());
            
            response.put("success", true);
            response.put("message", "令牌刷新成功");
            response.put("accessToken", newAccessToken);
            
            return ResponseEntity.ok()
                .header("Authorization", "Bearer " + newAccessToken)
                .body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "令牌刷新失败：" + e.getMessage());
            return ResponseEntity.status(401).body(response);
        }
    }

    /**
     * 验证令牌接口
     * 检查令牌是否有效并返回用户信息
     * 
     * @param authHeader 认证头（包含Bearer令牌）
     * @return 用户信息
     */
    @GetMapping("/verify")
    public ResponseEntity<Map<String, Object>> verifyToken(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String token = jwtUtil.extractTokenFromHeader(authHeader);
            
            if (token == null) {
                response.put("success", false);
                response.put("message", "缺少认证令牌");
                return ResponseEntity.status(401).body(response);
            }
            
            if (jwtUtil.validateToken(token)) {
                Map<String, Object> userInfo = jwtUtil.parseTokenToUserInfo(token);
                
                response.put("success", true);
                response.put("message", "令牌有效");
                response.put("user", userInfo);
                response.put("remainingTime", jwtUtil.getTokenRemainingTime(token));
                
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "令牌无效或已过期");
                return ResponseEntity.status(401).body(response);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "令牌验证失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    /**
     * 用户注册接口（示例）
     * 注册新用户并返回JWT令牌
     * 
     * @param registerRequest 注册请求
     * @return 注册结果
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody RegisterRequest registerRequest) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // 检查用户名是否已存在（示例逻辑）
            if (isUsernameExists(registerRequest.getUsername())) {
                response.put("success", false);
                response.put("message", "用户名已存在");
                return ResponseEntity.status(400).body(response);
            }
            
            // 创建新用户（示例逻辑，实际项目中应该保存到数据库）
            Long newUserId = createUser(registerRequest);
            
            // 生成令牌对
            Map<String, String> tokens = jwtUtil.generateTokenPair(
                registerRequest.getUsername(), newUserId, "USER");
            
            response.put("success", true);
            response.put("message", "注册成功");
            response.put("accessToken", tokens.get("accessToken"));
            response.put("refreshToken", tokens.get("refreshToken"));
            response.put("user", Map.of(
                "id", newUserId,
                "username", registerRequest.getUsername(),
                "role", "USER"
            ));
            
            return ResponseEntity.ok()
                .header("Authorization", "Bearer " + tokens.get("accessToken"))
                .header("X-Refresh-Token", tokens.get("refreshToken"))
                .body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "注册失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    /**
     * 登出接口
     * 使令牌失效（在实际项目中可以将令牌加入黑名单）
     * 
     * @param authHeader 认证头
     * @return 登出结果
     */
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String token = jwtUtil.extractTokenFromHeader(authHeader);
            
            if (token != null && jwtUtil.validateToken(token)) {
                // 在实际项目中，这里应该将令牌加入黑名单
                // 或者在Redis中标记为无效
                
                response.put("success", true);
                response.put("message", "登出成功");
            } else {
                response.put("success", false);
                response.put("message", "无效的令牌");
            }
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "登出失败：" + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    // ==================== 私有方法（示例实现） ====================

    /**
     * 验证用户凭据（示例实现）
     * 实际项目中应该查询数据库并验证密码哈希
     */
    private boolean validateUser(String username, String password) {
        // 示例：简单的用户验证
        // 实际项目中应该：
        // 1. 从数据库查询用户
        // 2. 验证密码哈希
        // 3. 检查用户状态（是否激活、是否被禁用等）
        return "admin".equals(username) && "123456".equals(password) ||
               "user".equals(username) && "password".equals(password);
    }

    /**
     * 检查用户名是否存在（示例实现）
     */
    private boolean isUsernameExists(String username) {
        // 示例：检查用户名是否已存在
        // 实际项目中应该查询数据库
        return "admin".equals(username) || "user".equals(username);
    }

    /**
     * 创建新用户（示例实现）
     */
    private Long createUser(RegisterRequest request) {
        // 示例：创建新用户
        // 实际项目中应该：
        // 1. 对密码进行哈希处理
        // 2. 保存用户信息到数据库
        // 3. 返回新用户的ID
        return System.currentTimeMillis(); // 使用时间戳作为示例ID
    }

    // ==================== 内部类（请求/响应模型） ====================

    /**
     * 登录请求模型
     */
    public static class LoginRequest {
        private String username;
        private String password;

        // Getters and Setters
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    /**
     * 刷新令牌请求模型
     */
    public static class RefreshTokenRequest {
        private String refreshToken;

        // Getters and Setters
        public String getRefreshToken() { return refreshToken; }
        public void setRefreshToken(String refreshToken) { this.refreshToken = refreshToken; }
    }

    /**
     * 注册请求模型
     */
    public static class RegisterRequest {
        private String username;
        private String password;
        private String email;
        private String phone;

        // Getters and Setters
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
    }
}