package com.zcpbysj.campusidletrade_server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zcpbysj.campusidletrade_server.entity.User;
import com.zcpbysj.campusidletrade_server.mapper.UserMapper;
import com.zcpbysj.campusidletrade_server.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;
//    实现菜品
@Service// 标识为 Spring 服务类（业务逻辑层）
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    // 基础 CRUD 方法已在 ServiceImpl 中实现，无需手动重写
    // 若有自定义业务方法，在此实现（示例：）
     @Override
     public List<User> getUsersByAge(Integer age) {
         QueryWrapper<User> wrapper = new QueryWrapper<>();
         wrapper.eq("age", age);
         return baseMapper.selectList(wrapper);
     }
    // 调用自定义 SQL 方法

   public List<User> selectUserByAge(Integer age) {
       // baseMapper 就是当前的 UserMapper（MyBatis-Plus 自动注入）
       // 直接调用 Mapper 中定义的 selectUserByAge 方法
       return baseMapper.selectUserByAge(age);
   }


}
