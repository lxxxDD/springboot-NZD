package com.zcpbysj.campusidletrade_server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zcpbysj.campusidletrade_server.entity.User;

import java.util.List;

public interface UserService extends IService<User> {
    // 基础 CRUD 方法已在 IService 中定义，若需自定义业务方法可在此添加
    // 示例：
    List<User> getUsersByAge(Integer age);
//点菜
    List<User> selectUserByAge(Integer age);
}
