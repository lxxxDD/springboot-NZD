package com.zcpbysj.campusidletrade_server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zcpbysj.campusidletrade_server.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
//厨师做菜
public interface UserMapper extends BaseMapper<User> {
    // 无需手动写方法！BaseMapper 已包含：
    // insert()（新增）、selectById()（按ID查询）、updateById()（按ID更新）、deleteById()（按ID删除）、list()（查询所有）等


    // 自定义方法：按年龄查询用户（方法名要和 XML 中的 id 一致）
    // @Param("age") 用于将参数传递给 XML 中的 SQL
     List<User> selectUserByAge(@Param("age") Integer age);
}
