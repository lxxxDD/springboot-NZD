package com.zcpbysj.campusidletrade_server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.Getter;

@Getter
@Data  // Lombok 注解：自动生成 getter、setter、toString 等方法
@TableName("user")  // 映射数据库表名（需与表名一致）
public class User {
    @TableId(type = IdType.AUTO)  // 主键策略：自增（与数据库表主键自增对应）
    private Long id;               // 主键ID
    private String name;           // 姓名（对应表中 name 字段）
    private Integer age;           // 年龄（对应表中 age 字段）
    private String email;          // 邮箱（对应表中 email 字段）
}
