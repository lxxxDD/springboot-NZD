package com.zcpbysj.campusidletrade_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusIdleTradeServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
